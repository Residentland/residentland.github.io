echo off
cd intro
java Intro
cd..
cd bird
java SkyMain
pause