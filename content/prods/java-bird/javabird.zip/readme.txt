  
 ++ another fine release from Resident ++ 


Greetings to all groups at 7d5...


JAVA BIRD (released at 7d5)
---------
code	: tesla
gfx	: spritus
zak	: flexi

*some of the gfx and sfx were taken from internet.


Controls:
---------
space	: shoot !
x	: change weapon 
arrows	: move
ESC	: exit 


That's all, good luck and use space!  