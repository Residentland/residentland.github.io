+--------------------------------+
|     Resident Meeting 2	 |
|				 |
|				 |
|	Kat�lanlar :		 |
|      --------------		 |
|	Spritus			 |
|	Tesla			 |
|				 |
|				 |
|	meetro_2 :		 |
|      --------------		 |
|	Spritus.....gfx, kod	 |
|	Tesla.......kod	 	 |
|	Flexi.......muzik	 |
|				 |
+--------------------------------+